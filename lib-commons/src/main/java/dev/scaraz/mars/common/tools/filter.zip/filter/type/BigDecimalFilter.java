package dev.scaraz.mars.common.tools.filter.type;

import dev.scaraz.mars.common.tools.filter.AbsRangeFilter;

import java.math.BigDecimal;
import java.util.Collection;

public class BigDecimalFilter extends AbsRangeFilter<BigDecimal> {
    @Override
    public BigDecimalFilter gt(BigDecimal greaterThan) {
        return (BigDecimalFilter) super.gt(greaterThan);
    }

    @Override
    public BigDecimalFilter gte(BigDecimal greaterThanEqual) {
        return (BigDecimalFilter) super.gte(greaterThanEqual);
    }

    @Override
    public BigDecimalFilter lt(BigDecimal lessThan) {
        return (BigDecimalFilter) super.lt(lessThan);
    }

    @Override
    public BigDecimalFilter lte(BigDecimal lessThanEqual) {
        return (BigDecimalFilter) super.lte(lessThanEqual);
    }

    @Override
    public BigDecimalFilter eq(BigDecimal value) {
        return (BigDecimalFilter) super.eq(value);
    }

    @Override
    public BigDecimalFilter notEq(BigDecimal value) {
        return (BigDecimalFilter) super.notEq(value);
    }

    @Override
    public BigDecimalFilter in(Collection<BigDecimal> value) {
        return (BigDecimalFilter) super.in(value);
    }

    @Override
    public BigDecimalFilter notIn(Collection<BigDecimal> value) {
        return (BigDecimalFilter) super.notIn(value);
    }
}

package dev.scaraz.mars.common.tools.filter.type;

import dev.scaraz.mars.common.tools.filter.AbsRangeFilter;
import dev.scaraz.mars.common.tools.filter.ReadableFilter;
import lombok.Getter;

import java.util.Collection;

@Getter
public class EnumFilter<T extends Enum<? super T>> extends AbsRangeFilter<T> implements ReadableFilter<T> {

    private T contain;
    private boolean specific;

    private T gt;
    private T gte;

    private T lt;
    private T lte;

    public EnumFilter<T> contain(T contain) {
        this.contain = contain;
        return this;
    }

    public EnumFilter<T> specific(boolean specific) {
        this.specific = specific;
        return this;
    }

    @Override
    public EnumFilter<T> gt(T greaterThan) {
        this.gt = greaterThan;
        return this;
    }

    @Override
    public EnumFilter<T> gte(T greaterThanEqual) {
        this.gte = greaterThanEqual;
        return this;
    }

    @Override
    public EnumFilter<T> lt(T lessThan) {
        this.lt = lessThan;
        return this;
    }

    @Override
    public EnumFilter<T> lte(T lessThanEqual) {
        this.lte = lessThanEqual;
        return this;
    }

    @Override
    public EnumFilter<T> eq(T value) {
        return (EnumFilter<T>) super.eq(value);
    }

    @Override
    public EnumFilter<T> notEq(T value) {
        return (EnumFilter<T>) super.notEq(value);
    }

    @Override
    public EnumFilter<T> in(Collection<T> value) {
        return (EnumFilter<T>) super.in(value);
    }

    @Override
    public EnumFilter<T> notIn(Collection<T> value) {
        return (EnumFilter<T>) super.notIn(value);
    }

}

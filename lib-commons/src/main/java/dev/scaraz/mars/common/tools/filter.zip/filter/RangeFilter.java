package dev.scaraz.mars.common.tools.filter;

import java.util.Collection;

public interface RangeFilter<T extends Comparable<? super T>> extends Filter<T> {
    RangeFilter<T> gt(T greaterThan);

    RangeFilter<T> gte(T greaterThanEqual);

    RangeFilter<T> lt(T lessThan);

    RangeFilter<T> lte(T lessThanEqual);

    @Override
    RangeFilter<T> eq(T value);

    @Override
    RangeFilter<T> notEq(T value);

    @Override
    RangeFilter<T> in(Collection<T> value);

    @Override
    RangeFilter<T> notIn(Collection<T> value);

    T getGt();
    T getGte();
    T getLt();
    T getLte();

}

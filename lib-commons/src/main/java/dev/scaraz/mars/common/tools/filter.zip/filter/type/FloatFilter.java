package dev.scaraz.mars.common.tools.filter.type;

import dev.scaraz.mars.common.tools.filter.AbsRangeFilter;

import java.util.Collection;

public class FloatFilter extends AbsRangeFilter<Float> {
    @Override
    public FloatFilter gt(Float greaterThan) {
        return (FloatFilter) super.gt(greaterThan);
    }

    @Override
    public FloatFilter gte(Float greaterThanEqual) {
        return (FloatFilter) super.gte(greaterThanEqual);
    }

    @Override
    public FloatFilter lt(Float lessThan) {
        return (FloatFilter) super.lt(lessThan);
    }

    @Override
    public FloatFilter lte(Float lessThanEqual) {
        return (FloatFilter) super.lte(lessThanEqual);
    }

    @Override
    public FloatFilter eq(Float value) {
        return (FloatFilter) super.eq(value);
    }

    @Override
    public FloatFilter notEq(Float value) {
        return (FloatFilter) super.notEq(value);
    }

    @Override
    public FloatFilter in(Collection<Float> value) {
        return (FloatFilter) super.in(value);
    }

    @Override
    public FloatFilter notIn(Collection<Float> value) {
        return (FloatFilter) super.notIn(value);
    }
}

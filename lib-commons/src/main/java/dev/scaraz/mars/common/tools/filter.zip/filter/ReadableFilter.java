package dev.scaraz.mars.common.tools.filter;

import java.util.Collection;

public interface ReadableFilter<T> extends Filter<T> {
    ReadableFilter<T> contain(T contain);

    ReadableFilter<T> specific(boolean specific);

    @Override
    ReadableFilter<T> eq(T value);

    @Override
    ReadableFilter<T> notEq(T value);

    @Override
    ReadableFilter<T> in(Collection<T> value);

    @Override
    ReadableFilter<T> notIn(Collection<T> value);

    T getContain();
    boolean isSpecific();

}

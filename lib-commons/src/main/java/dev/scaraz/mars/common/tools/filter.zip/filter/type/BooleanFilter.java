package dev.scaraz.mars.common.tools.filter.type;

import dev.scaraz.mars.common.tools.filter.AbsFilter;

import java.util.Collection;

public class BooleanFilter extends AbsFilter<Boolean> {
    @Override
    public BooleanFilter eq(Boolean value) {
        return (BooleanFilter) super.eq(value);
    }

    @Override
    public BooleanFilter notEq(Boolean value) {
        return (BooleanFilter) super.notEq(value);
    }

    @Override
    public BooleanFilter in(Collection<Boolean> value) {
        return (BooleanFilter) super.in(value);
    }

    @Override
    public BooleanFilter notIn(Collection<Boolean> value) {
        return (BooleanFilter) super.notIn(value);
    }
}

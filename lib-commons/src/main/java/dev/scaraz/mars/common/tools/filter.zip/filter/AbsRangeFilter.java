package dev.scaraz.mars.common.tools.filter;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Collection;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public abstract class AbsRangeFilter<T extends Comparable<? super T>> extends AbsFilter<T> implements RangeFilter<T> {

    private T gt;
    private T gte;

    private T lt;
    private T lte;

    public AbsRangeFilter<T> gt(T greaterThan) {
        this.gt = greaterThan;
        return this;
    }

    public AbsRangeFilter<T> gte(T greaterThanEqual) {
        this.gte = greaterThanEqual;
        return this;
    }

    public AbsRangeFilter<T> lt(T lessThan) {
        this.lt = lessThan;
        return this;
    }

    public AbsRangeFilter<T> lte(T lessThanEqual) {
        this.lte = lessThanEqual;
        return this;
    }

    @Override
    public AbsRangeFilter<T> eq(T value) {
        return (AbsRangeFilter<T>) super.eq(value);
    }

    @Override
    public AbsRangeFilter<T> notEq(T value) {
        return (AbsRangeFilter<T>) super.notEq(value);
    }

    @Override
    public AbsRangeFilter<T> in(Collection<T> value) {
        return (AbsRangeFilter<T>) super.in(value);
    }

    @Override
    public AbsRangeFilter<T> notIn(Collection<T> value) {
        return (AbsRangeFilter<T>) super.notIn(value);
    }
}

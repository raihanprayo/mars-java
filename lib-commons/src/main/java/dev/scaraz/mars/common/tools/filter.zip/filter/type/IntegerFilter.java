package dev.scaraz.mars.common.tools.filter.type;

import dev.scaraz.mars.common.tools.filter.AbsRangeFilter;

import java.util.Collection;

public class IntegerFilter extends AbsRangeFilter<Integer> {
    @Override
    public IntegerFilter gt(Integer greaterThan) {
        return (IntegerFilter) super.gt(greaterThan);
    }

    @Override
    public IntegerFilter gte(Integer greaterThanEqual) {
        return (IntegerFilter) super.gte(greaterThanEqual);
    }

    @Override
    public IntegerFilter lt(Integer lessThan) {
        return (IntegerFilter) super.lt(lessThan);
    }

    @Override
    public IntegerFilter lte(Integer lessThanEqual) {
        return (IntegerFilter) super.lte(lessThanEqual);
    }

    @Override
    public IntegerFilter eq(Integer value) {
        return (IntegerFilter) super.eq(value);
    }

    @Override
    public IntegerFilter notEq(Integer value) {
        return (IntegerFilter) super.notEq(value);
    }

    @Override
    public IntegerFilter in(Collection<Integer> value) {
        return (IntegerFilter) super.in(value);
    }

    @Override
    public IntegerFilter notIn(Collection<Integer> value) {
        return (IntegerFilter) super.notIn(value);
    }
}

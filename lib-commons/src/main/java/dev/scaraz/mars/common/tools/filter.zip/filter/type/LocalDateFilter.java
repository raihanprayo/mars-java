package dev.scaraz.mars.common.tools.filter.type;

import dev.scaraz.mars.common.tools.filter.AbsRangeFilter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.Collection;

public class LocalDateFilter extends AbsRangeFilter<LocalDate> {
    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    public LocalDateFilter gt(LocalDate greaterThan) {
        return (LocalDateFilter) super.gt(greaterThan);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    public LocalDateFilter gte(LocalDate greaterThanEqual) {
        return (LocalDateFilter) super.gte(greaterThanEqual);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    public LocalDateFilter lt(LocalDate lessThan) {
        return (LocalDateFilter) super.lt(lessThan);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    public LocalDateFilter lte(LocalDate lessThanEqual) {
        return (LocalDateFilter) super.lte(lessThanEqual);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    public LocalDateFilter eq(LocalDate value) {
        return (LocalDateFilter) super.eq(value);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    public LocalDateFilter notEq(LocalDate value) {
        return (LocalDateFilter) super.notEq(value);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    public LocalDateFilter in(Collection<LocalDate> value) {
        return (LocalDateFilter) super.in(value);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    public LocalDateFilter notIn(Collection<LocalDate> value) {
        return (LocalDateFilter) super.notIn(value);
    }
}

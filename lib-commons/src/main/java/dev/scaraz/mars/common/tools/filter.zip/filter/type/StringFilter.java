package dev.scaraz.mars.common.tools.filter.type;

import dev.scaraz.mars.common.tools.filter.AbsFilter;
import dev.scaraz.mars.common.tools.filter.ReadableFilter;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Collection;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class StringFilter extends AbsFilter<String> implements ReadableFilter<String> {

    private String contain;

    private boolean specific;

    public StringFilter contain(String contain) {
        this.contain = contain;
        return this;
    }

    public StringFilter specific(boolean specific) {
        this.specific = specific;
        return this;
    }

    @Override
    public StringFilter eq(String value) {
        return (StringFilter) super.eq(value);
    }

    @Override
    public StringFilter notEq(String value) {
        return (StringFilter) super.notEq(value);
    }

    @Override
    public StringFilter in(Collection<String> value) {
        return (StringFilter) super.in(value);
    }

    @Override
    public StringFilter notIn(Collection<String> value) {
        return (StringFilter) super.notIn(value);
    }

}

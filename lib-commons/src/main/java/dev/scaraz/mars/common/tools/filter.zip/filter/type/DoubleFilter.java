package dev.scaraz.mars.common.tools.filter.type;

import dev.scaraz.mars.common.tools.filter.AbsRangeFilter;

import java.util.Collection;

public class DoubleFilter extends AbsRangeFilter<Double> {
    @Override
    public DoubleFilter gt(Double greaterThan) {
        return (DoubleFilter) super.gt(greaterThan);
    }

    @Override
    public DoubleFilter gte(Double greaterThanEqual) {
        return (DoubleFilter) super.gte(greaterThanEqual);
    }

    @Override
    public DoubleFilter lt(Double lessThan) {
        return (DoubleFilter) super.lt(lessThan);
    }

    @Override
    public DoubleFilter lte(Double lessThanEqual) {
        return (DoubleFilter) super.lte(lessThanEqual);
    }

    @Override
    public DoubleFilter eq(Double value) {
        return (DoubleFilter) super.eq(value);
    }

    @Override
    public DoubleFilter notEq(Double value) {
        return (DoubleFilter) super.notEq(value);
    }

    @Override
    public DoubleFilter in(Collection<Double> value) {
        return (DoubleFilter) super.in(value);
    }

    @Override
    public DoubleFilter notIn(Collection<Double> value) {
        return (DoubleFilter) super.notIn(value);
    }
}

package dev.scaraz.mars.common.tools.filter.type;

import dev.scaraz.mars.common.tools.filter.AbsRangeFilter;

import java.util.Collection;

public class LongFilter extends AbsRangeFilter<Long> {
    @Override
    public LongFilter gt(Long greaterThan) {
        return (LongFilter) super.gt(greaterThan);
    }

    @Override
    public LongFilter gte(Long greaterThanEqual) {
        return (LongFilter) super.gte(greaterThanEqual);
    }

    @Override
    public LongFilter lt(Long lessThan) {
        return (LongFilter) super.lt(lessThan);
    }

    @Override
    public LongFilter lte(Long lessThanEqual) {
        return (LongFilter) super.lte(lessThanEqual);
    }

    @Override
    public LongFilter eq(Long value) {
        return (LongFilter) super.eq(value);
    }

    @Override
    public LongFilter notEq(Long value) {
        return (LongFilter) super.notEq(value);
    }

    @Override
    public LongFilter in(Collection<Long> value) {
        return (LongFilter) super.in(value);
    }

    @Override
    public LongFilter notIn(Collection<Long> value) {
        return (LongFilter) super.notIn(value);
    }
}

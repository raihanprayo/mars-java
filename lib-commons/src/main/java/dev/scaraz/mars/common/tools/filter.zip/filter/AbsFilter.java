package dev.scaraz.mars.common.tools.filter;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Collection;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public abstract class AbsFilter<T> implements Filter<T> {

    protected T eq;
    protected T notEq;

    protected Collection<T> in;
    protected Collection<T> notIn;

    public AbsFilter<T> eq(T value) {
        this.eq = value;
        return this;
    }

    public AbsFilter<T> notEq(T value) {
        this.notEq = value;
        return this;
    }

    public AbsFilter<T> in(Collection<T> value) {
        this.in = value;
        return this;
    }

    public AbsFilter<T> notIn(Collection<T> value) {
        this.notIn = value;
        return this;
    }

}

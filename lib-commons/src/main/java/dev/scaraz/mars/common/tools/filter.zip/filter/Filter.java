package dev.scaraz.mars.common.tools.filter;

import java.io.Serializable;
import java.util.Collection;

public interface Filter<T> extends Serializable {
    Filter<T> eq(T value);

    Filter<T> notEq(T value);

    Filter<T> in(Collection<T> value);

    Filter<T> notIn(Collection<T> value);

    T getEq();
    T getNotEq();
    Collection<T> getIn();
    Collection<T> getNotIn();
}

package dev.scaraz.mars.common.tools.filter.type;

import dev.scaraz.mars.common.tools.filter.AbsRangeFilter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.Instant;
import java.util.Collection;

public class InstantFilter extends AbsRangeFilter<Instant> {
    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public InstantFilter gt(Instant greaterThan) {
        return (InstantFilter) super.gt(greaterThan);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public InstantFilter gte(Instant greaterThanEqual) {
        return (InstantFilter) super.gte(greaterThanEqual);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public InstantFilter lt(Instant lessThan) {
        return (InstantFilter) super.lt(lessThan);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public InstantFilter lte(Instant lessThanEqual) {
        return (InstantFilter) super.lte(lessThanEqual);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public InstantFilter eq(Instant value) {
        return (InstantFilter) super.eq(value);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public InstantFilter notEq(Instant value) {
        return (InstantFilter) super.notEq(value);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public InstantFilter in(Collection<Instant> value) {
        return (InstantFilter) super.in(value);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public InstantFilter notIn(Collection<Instant> value) {
        return (InstantFilter) super.notIn(value);
    }
}

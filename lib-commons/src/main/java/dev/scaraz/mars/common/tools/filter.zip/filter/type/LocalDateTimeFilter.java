package dev.scaraz.mars.common.tools.filter.type;

import dev.scaraz.mars.common.tools.filter.AbsRangeFilter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.Collection;

public class LocalDateTimeFilter extends AbsRangeFilter<LocalDateTime> {
    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public LocalDateTimeFilter gt(LocalDateTime greaterThan) {
        return (LocalDateTimeFilter) super.gt(greaterThan);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public LocalDateTimeFilter gte(LocalDateTime greaterThanEqual) {
        return (LocalDateTimeFilter) super.gte(greaterThanEqual);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public LocalDateTimeFilter lt(LocalDateTime lessThan) {
        return (LocalDateTimeFilter) super.lt(lessThan);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public LocalDateTimeFilter lte(LocalDateTime lessThanEqual) {
        return (LocalDateTimeFilter) super.lte(lessThanEqual);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public LocalDateTimeFilter eq(LocalDateTime value) {
        return (LocalDateTimeFilter) super.eq(value);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public LocalDateTimeFilter notEq(LocalDateTime value) {
        return (LocalDateTimeFilter) super.notEq(value);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public LocalDateTimeFilter in(Collection<LocalDateTime> value) {
        return (LocalDateTimeFilter) super.in(value);
    }

    @Override
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    public LocalDateTimeFilter notIn(Collection<LocalDateTime> value) {
        return (LocalDateTimeFilter) super.notIn(value);
    }
}
